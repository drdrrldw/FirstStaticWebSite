
public class Monster {
		private String monsterName;
		private int monsterHp;
		private String monsterWeapon;
		private int monsterDamage;
		
		
		
		
}
