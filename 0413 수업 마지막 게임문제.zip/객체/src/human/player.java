package human;

public class player {
	
	private String playerName;   // 이름
	private int playerHp = 500;		// 체력
	private int playerDamage = 1; 		// 공격력
	private weapon playerEquipment; 
	
	
	//플레이어 이름 입력값을 객체에 저장
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	
	//저장된 플레이어 이름을 보냄
	public String getPlayerName() {
		return playerName;
	}
	
	
//	
//	public void setPlayerEquip(String playerChooseWeapon) {
//		this.playerEquipment = playerChooseWeapon;
//	}
	
	public String getPlayerEquip() {
		return playerEquipment;
	}
	
	
}
