package human;

public class weapon {

	private String playerEquipmentw;   // 무기이름
	private String weaponCategoryw;		// 무기종류
	private int weaponDamagew; 		// 무기공격력
	
	
	
	
	
	
	weapon(String weaponName) {
		this.playerEquipmentw = weaponName;
		

		if (weaponName == "맨손") {
			this.weaponCategoryw = "맨주먹";
			this.weaponDamagew = 20;
		} else if(weaponName == "검") {
			this.weaponCategoryw = "근거리";
			this.weaponDamagew = 50;
		} else if (weaponName == "활") {
			this.weaponCategoryw = "원거리";
			this.weaponDamagew = 40;
		}
		
		
	}


	
	
	
	public void setPlayerEquipment(String playerEquipment) {
		playerEquipmentw = playerEquipment;
	}

	
	
	public String getPlayerEquipment() {
		return this.playerEquipmentw;
	}





	public void setWeaponCategory(String weaponCategory) {
		weaponCategoryw = weaponCategory;
	}

	public String getWeaponCategory() {
		return this.weaponCategoryw;
	}




	public void setWeaponDamage(int weaponDamage) {
		weaponDamagew = weaponDamage;
	}


	public int getWeaponDamage() {
		return this.weaponDamagew;
	}



	
	
	
	
	
	
}
