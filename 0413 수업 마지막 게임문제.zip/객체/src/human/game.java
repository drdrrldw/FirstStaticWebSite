package human;

import java.util.Scanner;

public class game {
	public static void main(String[] args) {
	

		System.out.println("플레이어의 이름을 입력해보세요.");
		Scanner playerNameInput = new Scanner(System.in);
		String playerName = playerNameInput.nextLine();
		System.out.println("당신이 입력한 이름은 : "+ playerName);
		
		
		player gamePlayerInfo = new player();
		gamePlayerInfo.setPlayerName(playerName);
		
		
		
		System.out.println("플레이어가 사용할 무기를 입력해주세요. ''안의 글씨만 입력하세요.  '맨손', '검', '활' ");
		Scanner playerWeaponInput = new Scanner(System.in);
		String playerChooseWeapon = playerWeaponInput.nextLine();
		System.out.println("당신이 고른 무기는 : "+ playerChooseWeapon);
		
		weapon playerEquipInfo = new weapon(playerChooseWeapon);
				String playerWp = playerEquipInfo.getPlayerEquipment();
				String playerWeaponCt = playerEquipInfo.getWeaponCategory();
				int playerWeaponDa = playerEquipInfo.getWeaponDamage();
		
		
		System.out.println(playerWp);
		System.out.println(playerWeaponCt);
		System.out.println(playerWeaponDa);
		
		
		
		
		
	}
	
	
}
