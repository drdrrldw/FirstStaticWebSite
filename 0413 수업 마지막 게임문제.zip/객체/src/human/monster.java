package human;

public class monster {
	
	private String monsterName;   // 이름
	private int monsterHp;		// 체력
	private int monsterDamage; 		// 공격력
	
	

}
