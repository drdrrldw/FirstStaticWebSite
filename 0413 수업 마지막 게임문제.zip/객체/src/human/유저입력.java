package human;

import java.util.Scanner;

public class 유저입력 {
	public static void main(String[] args) {
		
		System.out.println("당신의 이름을 입력해보세요.");
		Scanner sc = new Scanner(System.in);
		String myName = sc.nextLine(); 	//한줄을 입력받는 함수 호출. 키보드로부터 입력받음.
		System.out.println("당신이 입력한 이름은 : "+ myName);
	}
}
