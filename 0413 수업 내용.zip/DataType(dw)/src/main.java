
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		메모리 human1gb = new 메모리();
		System.out.println(human1gb.getMaxSize()/1024 + "GB입니다.");
		
		human1gb.save(500);
		
	}

}
