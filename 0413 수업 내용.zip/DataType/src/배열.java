import java.util.Arrays;

public class 배열 {
	public static void main(String[] args) {
		
		String[] weeks = {"월","화","수","목","금","토","일"};
		
		
		System.out.println(weeks[2]);
		System.out.println(weeks);//@71dac704
		
		for (String elem : weeks) {
			System.out.println(elem);
		}
		
		//2차원배열
		String[][] arr = {{"1-1","1-2","1-3","1-4","1-5"},{"2-1","2-2","2-3","2-4","2-5"}};
		for(String[] oneDemen : arr) {
			for(String element : oneDemen) {
//				System.out.print(Arrays.toString(oneDemen));
//				System.out.println();
				System.out.print(element + " ");
			}
			System.out.println();
		}
		
		
		
	}
	
	
}
