
public class 문자열 {
	public static void main(String[] args) {
		String str1 = "hello world";
		String str2 = new String("this is Korea");
		
		String str3 = str1;
		str3 = "Bye world";
		System.out.println(str1);
		str3 = str2;
		str3 = "this is Sparta";
		System.out.println(str2);

		
		String name1 = "japan";
		String name2 = "japan";
		String name3 = new String("japan");
		System.out.println(name1.equals(name3));
		//equals는 값을 비교.  ==는 객체를 비교
		
		//indexOf = 값을 통해 인덱스를 가져옴
		System.out.println(name1.indexOf("p"));
		
		//contains = 값이 있으면 true, 없으면 false를 반환
		if(name1.contains("pan")) {
			System.out.println("pan이 있습니다.");
		}
		
		//charAt = 인덱스를 통해 값을 가져옴
		System.out.println(name3.charAt(4));
		
		//replaceAll() 첫번째 인자를 두번째 인자로 치환
		name3 = name3.replaceAll("a", "i");
		System.out.println(name3);
		
		//substring  시작문자열 포함, 끝문자열 미만의 문자열 가져옴
		System.out.println(str3.substring(8,14));
		
		//split 구분자를 기준으로 나눠서 가져옴
		String rainbow = "빨,주,노,초,파,남,보";
		String[]arr = rainbow.split(",");
		for(int i=0; i<arr.length; i++) {
			System.out.println(arr[i]);
		}
		
		//format
		String difficultSentence = String.format("나는 %d의 피자를 먹을수 있습니다. 오늘은 %d만큼 먹었습니다.", 20, 5);
		System.out.println(difficultSentence);
		
		System.out.printf("나는 %d의 피자를 먹을수 있습니다. 오늘은 %d만큼 먹었습니다.", 20, 5);


	}
}
