
public class 메모리 {
	private int maxSize = 1024*1000;	//최대용량
	private int prsentSize = 0;			//현재 사용중인 용량
	private int price = 200000;			//가격
	private String maker = "samsung";	//제조사
	
	
	// 생성자는 이 클래스(설계도)대로 인스턴스를 생성할때 쓰인다.
	// 정의하는법 = 접근제한자 클래스명(인자){ 본문 }
		//함수 정의하는것과 비슷하게 생겼는데 return이 없고 이름이 클래스명이다.
	// 인자가 있다는 말은 이놈이 세상에 태어날때 반드시 그 정보가 있어야 한다를 말한다.
	
	
	
	
	//오버로딩.  이름이 같지만 인자의 데이터타입과 갯수에 따라 그에 맞는 함수가 호출되는 기술.
	public 메모리() {
		
	}
	
	
	public 메모리(String brandName) {
		this.maker = brandName;
	}
	
	

	public 메모리(String brandName, int Size) {
		this.maker = brandName;
		this.maxSize = Size;
	}
	
	
	
	
	
	public int getMaxSize() {
		return maxSize;
	}

	public void setMaxSize(int maxSize) {
		this.maxSize = maxSize;
	}

	public int getPrsentSize() {
		return prsentSize;
	}

	public void setPrsentSize(int prsentSize) {
		this.prsentSize = prsentSize;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	//인자로 받은 용량만큼 현재용량에 저장
	public boolean save(int addSize) {
		if((prsentSize + addSize)>maxSize) {
			System.out.printf("현재용량 : %d, 추가용량 : %d, 최대용량 : %d\n", prsentSize,addSize,maxSize);
			System.out.printf("%d만큼의 용량이 더 필요합니다.", (prsentSize+addSize)-maxSize);
			//현재용량 40, 추가용량 80, 최대용량 100이면 20만큼 더 필요
			return false;
		}else {
			prsentSize += addSize;
			System.out.println(addSize+"가 저장되어 현재용량 : "+prsentSize);
			return true;
		}
	}
	
	//인자로 받은 용량만큼 빼짐
	public boolean load(int minusSize) {
		int leftSize = prsentSize - minusSize;
		if(leftSize <0) {
			System.out.println("불가능합니다");
			return false;
		}else {
			prsentSize-=minusSize;
			System.out.println(minusSize+"만큼 용량이 확보되어 현재용량 : "+prsentSize);
			return true;
		}
	}

	
}
