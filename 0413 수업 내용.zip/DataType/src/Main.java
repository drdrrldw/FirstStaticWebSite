
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		메모리 samsung1tb = new 메모리();       // 메모리의 디폴트 생성자로 인스턴스 생성
//		System.out.println(samsung1tb.getMaxSize()/1024+
//		
//		samsung1tb.save(500*1024);
//		samsung1tb.save(501*1024);
//		samsung1tb.load(200*1024);
//		samsung1tb.save(501*1024);
//
//		메모리 lg1tb = new 메모리("LG");
//		메모리 samsung4tb = new 메모리("samsung", 1024*4*1000);
//		
		
		

		물병 human200btl = new 물병(200, 0);
		System.out.println(human200btl.getMaxVol()+"L의 용량을 채울수 있습니다.");
	
		human200btl.putIn(20);
		human200btl.putIn(30);
		human200btl.putIn(40);
		
		System.out.println(human200btl.calcLeft());
	}


	
	
	
	
	
}
