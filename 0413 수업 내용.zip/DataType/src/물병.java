
public class 물병 {

	private double maxVol;//최대용량
	private double nowVol;	//현재용량
	
	    

	public 물병(int maxVol) {
		super();	// 부모가있어야 자식이 존재할수 있다. 부모 인스턴스를 생성해주고 있는것.
		this.maxVol = maxVol;
		this.nowVol = 0;
	}
	
    // this는 자기를 말하고 super는 부모를 말한다.
	// super() 괄호를 열고 닫고 하고 있네? 어? 이거 함수 호출인가? 그런데 클래스의 이름과 같네? 아 생성자의 호출이구나.
	// super() 부모클래스명() 부모 클래스의 디폴트 생성자를 호출.
    
    
	public 물병(int maxVol, int nowVol) {
		super();	// 부모가있어야 자식이 존재할수 있다. 부모 인스턴스를 생성해주고 있는것.
		this.maxVol = maxVol;
		this.nowVol = nowVol;
	}
	
	
	
	
	public double getMaxVol() {
		return maxVol;
	}
	public void setMaxVol(int maxVol) {
		this.maxVol = maxVol;
	}
	public double getNowVol() {
		return nowVol;
	}

	public void setNowVol(int nowVol){
		this.nowVol = nowVol;
	}
	
	
	
	public boolean putIn(double addVol){
		double nowSize = nowVol + addVol;
		
		if(nowSize > maxVol) {
			System.out.println("최대용량 : %d , 추가로 넣은 용량 : %d, 현재 용량 : %d , 최대용량을 넘을수 없습니다.");
			System.out.printf("%d만큼의 용량이 더 필요합니다.", (nowVol+addVol)-maxVol);
			return false;
		} else {
			nowVol = nowSize;
			System.out.println(addVol+"가 저장되어 현재용량 : "+nowVol);
			return true;
		}
	}
	
	
		
	public boolean drain(double minusVol){
		double leftSize = nowVol - minusVol;
		
		if(leftSize < 0) {
			System.out.println("불가능합니다");
			return false;
		}else {
			nowVol = leftSize;
			System.out.println(minusVol+"만큼 용량이 확보되어 현재용량 : "+nowVol);
			return true;
		}
	}
	
//	
//	calcLeft() 남은 용량 계산
//	
//	
//	empty()  현재 용량 다 비우기
	
	public double calcLeft() {
		return maxVol - nowVol;
				
	}
	
	
	public void empty() {
		
		nowVol = 0;
		System.out.println("용량을 비웠습니다. 현재 남은 용량은 %d 입니다.");
		
	}
	
	
}
