// 스타벅스 배열 // 

var productArrStarbucksAll = new Array("../이미지모음/커피 종류 사진/section2/스타벅스메뉴/카페아메리카노.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/아이스카페아메리카노.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/카푸치노.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/아이스카푸치노.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/카페라떼.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/아이스카페라떼.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/카라멜마키야또.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/아이스카라멜마키야또.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/콜드블루.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/돌체밀크티.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/아이스돌체블랙밀크티.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/캐모마일 브렌드티.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/아이스캐모마일브랜드티.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/히비스커스브렌드티.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/아이스히비스커스브렌드티.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/자바침프라푸치노.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/바닐라크립프라푸치노.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/에스프레소프라푸치노.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/제주그린한라봉모히또블렌디드.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/트위스트피치요거트블렌디드.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/딸기딜라이트요거트블렌디드.jpg");

var productArrStarbucksCoffee = new Array("../이미지모음/커피 종류 사진/section2/스타벅스메뉴/카페아메리카노.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/아이스카페아메리카노.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/카푸치노.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/아이스카푸치노.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/카페라떼.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/아이스카페라떼.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/카라멜마키야또.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/아이스카라멜마키야또.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/콜드블루.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/에스프레소프라푸치노.jpg");

var productArrStarbucksBeverage = new Array("../이미지모음/커피 종류 사진/section2/스타벅스메뉴/제주그린한라봉모히또블렌디드.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/트위스트피치요거트블렌디드.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/딸기딜라이트요거트블렌디드.jpg");

var productArrStarbucksTea = new Array("../이미지모음/커피 종류 사진/section2/스타벅스메뉴/돌체밀크티.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/아이스돌체블랙밀크티.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/캐모마일 브렌드티.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/아이스캐모마일브랜드티.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/히비스커스브렌드티.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/아이스히비스커스브렌드티.jpg")

var productArrStarbucksSlush = new Array("../이미지모음/커피 종류 사진/section2/스타벅스메뉴/자바침프라푸치노.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/바닐라크립프라푸치노.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/에스프레소프라푸치노.jpg");

var productArrStarbucksAdeShake = new Array("../이미지모음/커피 종류 사진/section2/스타벅스메뉴/제주그린한라봉모히또블렌디드.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/트위스트피치요거트블렌디드.jpg","../이미지모음/커피 종류 사진/section2/스타벅스메뉴/딸기딜라이트요거트블렌디드.jpg");

var arrStarbucks = [productArrStarbucksAll, productArrStarbucksCoffee,productArrStarbucksBeverage, productArrStarbucksTea, productArrStarbucksSlush, productArrStarbucksAdeShake];


//  탐앤 탐스 배열 // 


var productArrTomandtomsAll = new Array("../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐아메리카노.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐아이스아메리카노.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐카푸치노.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐아이스카푸치노.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐카페라떼.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐카라멜마키야또.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐아이스카라멜마키야또.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐콜드블루.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐딸가라떼.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐레몬티.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐아이스레몬티.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐로얄밀크티.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐아이스로얄밀크티.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐캐모마일.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐딸리쇼트케잌탐엔치노.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐바닐라탐엔치노.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐자바칩탐엔치노.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐오렌지에이드.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐자몽에이드.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐레몬에이드.jpg");

var productArrTomandtomsCoffee = new Array("../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐아메리카노.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐아이스아메리카노.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐카푸치노.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐아이스카푸치노.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐카페라떼.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐카라멜마키야또.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐아이스카라멜마키야또.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐콜드블루.jpg");

var productArrTomandtomsBeverage = new Array("../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐딸가라떼.jpg");
var productArrTomandtomsTea = new Array("../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐레몬티.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐아이스레몬티.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐로얄밀크티.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐아이스로얄밀크티.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐캐모마일.jpg");

var productArrTomandtomsSlush = new Array("../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐딸리쇼트케잌탐엔치노.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐바닐라탐엔치노.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐자바칩탐엔치노.jpg");

var productArrTomandtomsAdeShake = new Array("../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐오렌지에이드.jpg","../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐자몽에이드.jpg",
"../이미지모음/커피 종류 사진/section2/탐탐메뉴/탐레몬에이드.jpg");


var arrTomandtoms = [productArrTomandtomsAll, productArrTomandtomsCoffee, productArrTomandtomsBeverage, productArrTomandtomsTea, productArrTomandtomsSlush, productArrTomandtomsAdeShake];


// 이디야 배열 //

var productArrEdiyaAll = ["../이미지모음/커피 종류 사진/section2/이디야메뉴/디아메리카노.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스아메리카노.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디카페라떼.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스카페라떼.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디카푸치노.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스카푸치노.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디카페라떼.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스카페라떼.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디카라멜마키야또.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스카라멜마키야또.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디콜드블루.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디딸기라떼.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디밀크티.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스밀크티.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디샤인히비스커스.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스샤인히비스커스.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스피치얼그레이티.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디피치얼그레이티.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디생딸기연유플랫치노.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디초콜릿칩플랫치노.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디토피넛플랫치노.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디레몬에이드.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디자몽에이드.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디청포도에이드.jpg"];


var productArrEdiyaCoffee = ["../이미지모음/커피 종류 사진/section2/이디야메뉴/디아메리카노.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스아메리카노.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디카페라떼.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스카페라떼.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디카푸치노.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스카푸치노.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디카페라떼.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스카페라떼.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디카라멜마키야또.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스카라멜마키야또.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디콜드블루.jpg"];

var productArrEdiyaBevarage = ["../이미지모음/커피 종류 사진/section2/이디야메뉴/디딸기라떼.jpg"];
var productArrEdiyaTea = ["../이미지모음/커피 종류 사진/section2/이디야메뉴/디밀크티.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스밀크티.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디샤인히비스커스.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스샤인히비스커스.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디아이스피치얼그레이티.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디피치얼그레이티.jpg"];
var productArrEdiyaSlush = ["../이미지모음/커피 종류 사진/section2/이디야메뉴/디생딸기연유플랫치노.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디초콜릿칩플랫치노.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디토피넛플랫치노.jpg"];

var productArrEdiyaAdeShake = ["../이미지모음/커피 종류 사진/section2/이디야메뉴/디레몬에이드.jpg","../이미지모음/커피 종류 사진/section2/이디야메뉴/디자몽에이드.jpg",
"../이미지모음/커피 종류 사진/section2/이디야메뉴/디청포도에이드.jpg"];

var arrEdiya = [productArrEdiyaAll, productArrEdiyaCoffee, productArrEdiyaBevarage, productArrEdiyaTea, productArrEdiyaSlush, productArrEdiyaAdeShake];



// 할리스 배열 // 

var productArrHollysAll = ["../이미지모음/커피 종류 사진/section2/할리스메뉴/할아메리카노.jpg","../이미지모음/커피 종류 사진/section2/할리스메뉴/할아이스아메리카노.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할카푸치노.jpg","../이미지모음/커피 종류 사진/section2/할리스메뉴/할카페라떼.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할아이스카페라떼.jpg","../이미지모음/커피 종류 사진/section2/할리스메뉴/할카라멜마키야또.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할콜드블루.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할딸기라떼.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할밀크티라떼.jpg","../이미지모음/커피 종류 사진/section2/할리스메뉴/할생딸기라떼.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할얼그레이.jpg","../이미지모음/커피 종류 사진/section2/할리스메뉴/할아이스얼그레이.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할캐모마일.jpg","../이미지모음/커피 종류 사진/section2/할리스메뉴/할아이스캐모마일.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할콜드블루할리치노.jpg","../이미지모음/커피 종류 사진/section2/할리스메뉴/할다크초롤릿칩할리치노.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할딸기_치즈케잌할리치노.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할복숭아자두스파클링.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할청포도스파클링.jpg"];


var productArrHollysCoffee = ["../이미지모음/커피 종류 사진/section2/할리스메뉴/할아메리카노.jpg","../이미지모음/커피 종류 사진/section2/할리스메뉴/할아이스아메리카노.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할카푸치노.jpg","../이미지모음/커피 종류 사진/section2/할리스메뉴/할카페라떼.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할아이스카페라떼.jpg","../이미지모음/커피 종류 사진/section2/할리스메뉴/할카라멜마키야또.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할콜드블루.jpg", "../이미지모음/커피 종류 사진/section2/할리스메뉴/할콜드블루할리치노.jpg"];

var productArrHollysBeverage = ["../이미지모음/커피 종류 사진/section2/할리스메뉴/할딸기라떼.jpg","../이미지모음/커피 종류 사진/section2/할리스메뉴/할밀크티라떼.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할생딸기라떼.jpg"];

var productArrHollysTea = ["../이미지모음/커피 종류 사진/section2/할리스메뉴/할얼그레이.jpg","../이미지모음/커피 종류 사진/section2/할리스메뉴/할아이스얼그레이.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할캐모마일.jpg","../이미지모음/커피 종류 사진/section2/할리스메뉴/할아이스캐모마일.jpg"];

var productArrHollysSlush = ["../이미지모음/커피 종류 사진/section2/할리스메뉴/할콜드블루할리치노.jpg","../이미지모음/커피 종류 사진/section2/할리스메뉴/할다크초롤릿칩할리치노.jpg",
"../이미지모음/커피 종류 사진/section2/할리스메뉴/할딸기_치즈케잌할리치노.jpg"];

var productArrHollysAdeShake = [ "../이미지모음/커피 종류 사진/section2/할리스메뉴/할복숭아자두스파클링.jpg",  "../이미지모음/커피 종류 사진/section2/할리스메뉴/할청포도스파클링.jpg"];


var arrHollys = [productArrHollysAll, productArrHollysCoffee, productArrHollysBeverage, productArrHollysTea, productArrHollysSlush, productArrHollysAdeShake ];


// ↑ 위로 각 브랜드 별로 배열 저장영역 //






function onclickBrand(number){

  let imgArr = document.getElementsByClassName("productImg");
  
  for(let i = 0; i < imgArr.length; i++){
     imgArr[i].src = null;
  }


  if(number == 1){
    productArrBrand = arrStarbucks;
  } else if(number == 2){
    productArrBrand = arrTomandtoms;
  } else if(number == 3){
    productArrBrand = arrEdiya;
  } else if(number == 4){
    productArrBrand = arrHollys;
  }

  for(let i=0; i < productArrBrand[0].length+1 ; i++){
    imgArr[i].src = productArrBrand[0][i];
  }

}










function checkedPrintImg(checkbox1){
  
  let checkedRadio = new Object(checkbox1);
  let imgArr = document.getElementsByClassName("productImg");
  
  for(let i = 0; i < imgArr.length; i++){
     imgArr[i].src = null;
  }


  if(checkedRadio.value == 0){
    for(let i=0; i < productArrBrand[0].length+1 ; i++){
      imgArr[i].src = productArrBrand[0][i];
    }
  } else if(checkedRadio.value == 1){
    for(let i=0; i < productArrBrand[1].length+1 ; i++){
      imgArr[i].src = productArrBrand[1][i];
    }
  } else if(checkedRadio.value == 2){
    for(let i=0; i < productArrBrand[2].length+1 ; i++){
      imgArr[i].src = productArrBrand[2][i];
    }
  } else if(checkedRadio.value == 3){
    for(let i=0; i < productArrBrand[3].length+1 ; i++){
      imgArr[i].src = productArrBrand[3][i];
    }
  } else if(checkedRadio.value == 4){
    for(let i=0; i < productArrBrand[4].length+1 ; i++){
      imgArr[i].src = productArrBrand[4][i];
    }
  } else if(checkedRadio.value == 5){
    for(let i=0; i < productArrBrand[5].length+1 ; i++){
      imgArr[i].src = productArrBrand[5][i];
    }
  }




}

